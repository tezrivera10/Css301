// Raul Rivera
// 5/14/19

//Module 5 problem 4

// Problem 4 - Create and print an example using 
// each of the following artihmetic operators: +, -, *, /, %, ++, and --.

public class M5P4
{
  public static void main(String []args)
  {
    int x = 10;
    int y = 5;
    int test1;
    
    // Use this method
    test1 = x + y;
    int test2 = x * y;
    
    System.out.println(test1);
    System.out.println(test2);    
      
  }
}