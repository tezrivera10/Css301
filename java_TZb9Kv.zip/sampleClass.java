// Raul Rivera

//5/21/19

// Module 7 problem 1

public class sampleClass
{
  
  int x;
  
  public static void main(String [] args)
  {
    sampleClass myObj = new sampleClass();
    
    myObj.x = 12;
System.out.println(myObj.x);
  
  }
}
    

