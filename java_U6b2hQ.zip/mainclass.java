//Raul Rivera
// 6/4/19

// Module 9 problem 1 


class Animal {
  public void animalSound() {
    System.out.println("The animal makes a sound");
  }
}

class Pig extends Animal {
  public void animalSound() {
    System.out.println("The pig says: wee wee");
  }
}
 class Dog extends Animal
 {
	public void animalSound()
    {
      System.out.println("The dog says: woof");
    }
}
class Cat extends Animal 
{
 public void animalSound()
 {
  System.out.println("The cat says: meow");
   }
}
public class mainclass
{
  public static void main(String [] args)
  {
    Animal pigObj = new Pig();
    Animal catObj = new Cat();
    Animal dogObj = new Dog();
    
    pigObj.animalSound();
    catObj.animalSound();
    dogObj.animalSound();
  }
}