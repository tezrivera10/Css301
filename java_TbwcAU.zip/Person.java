// Raul Rivera
// 5/28/19


// Module 8 lab activity

public class Person
{
  private String name;
  
  public String getName()
  {
    
    	return name;
  }


    
  
  
  public void setName(String newName)
  {
    
    name = newName;
    
  }
}

