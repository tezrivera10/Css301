// Raul Rivera
// 5/28/19


// Module 8 lab activity

public class Heaven
{

  public static void main(String[] args)
  {
    Person obj = new Person();
    
     //setting values of the variables
    obj.setName("Raul");
    
      
    //Displaying values of the variables
      System.out.println(obj.getName());
    
    
  }  
}