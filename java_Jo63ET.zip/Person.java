// Raul Rivera
// 5/28/19


// Moddule 8 Lab activity


public class Person
{
  private String name;
  
}