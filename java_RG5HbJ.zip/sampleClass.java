// Raul Rivera

//5/21/19

// Module 7 problem 3


public class sampleClass
{
  
  int x = 6;
  
  public static void main(String [] args)
  {
    sampleClass myObj = new sampleClass();
    
    myObj.x = 12;
	System.out.println(myObj.x);
    
    sampleClass myObj2 = new sampleClass();
    System.out.println(myObj2.x);
  
  }
}
    