//Raul Rivera
//5/14/19

//Module 5 Problem 6


// Problem 6- create and print an example of each of the following java logical operators: &&, ||, and !.

public class M5P6
{
  public static void main(String []args)
  {
    
    int x = 123;
    
    System.out.println(x < 15 && x > 5);
    System.out.println(x < 5 || x > 8);
    System.out.println(!(x < 15 || x > 8));
    
  }
}